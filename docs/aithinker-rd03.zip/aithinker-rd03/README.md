# aithinker-rd03
Arduino software to interface an ESP8266 with the AiThinker RD-03 radar module
