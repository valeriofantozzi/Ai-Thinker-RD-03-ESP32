# Ai-Thinker-RD-03
Arduino library for the RD-03 radar module for movement detection by Ai-Thinker

PLEASE NOTE: I am a hobbyist. I have no affiliation with any manufacturer developing or selling radar modules.

*** UNDER DEVELOPEMENT ***

  This sensor is a Frequency Modulated Continuous Wave radar, which makes it good for  detection of micromovements and its sensitivity at different ranges can be configured. In debugging mode can output the raw dopler data.
 
  todo:
   - better documentation
   - examples
   - support for new firmware, maybe ... factory settings (undocumented)

  The code in this library was developed from scratch based on the manufacturer datasheet(s) (some in chinese, google translated...) 
  
  
  History of changes:
   - 09.02.2024 - v0.7.0 initial 

This library is distributed in the hope that it will be useful, but
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE either express or implied.
Released into the public domain.

Released under LGPL-2.1 see https://github.com/Gjorgjevikj/HLK_LD2410/blob/master/LICENSE for full license
